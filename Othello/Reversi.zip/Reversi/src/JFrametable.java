import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class JFrametable extends JFrame {
	
	static Reversi r = new Reversi();
	JLabel [][] table = new JLabel[8][8];
	ImageIcon [] backImage = new ImageIcon[2];
	ImageIcon [] blackCh = new ImageIcon[2];
	ImageIcon [] whiteCh = new ImageIcon[2];
	ImageIcon wa = new ImageIcon("src//picture//wa.jpg");
	ImageIcon ba = new ImageIcon("src//picture//ba.jpg");
	JLabel bl;
	int wigth = 500,higth = 500;
	public JFrametable(){
		
		Container cp = this.getContentPane();
		cp.setLayout(null);
		
		//java.net.URL imgURL = JFrametable.class.getResource("/picture/1.png");
		System.out.print(JFrametable.class.getResource("picture/1.png"));
		backImage[0] = new ImageIcon(JFrametable.class.getResource("picture/1.png"));
		//backImage[0] = new ImageIcon("src//picture//1.png");
		backImage[1] = new ImageIcon("src//picture//2.png");
		blackCh[0] = new ImageIcon("src//picture//b1.png");
		blackCh[1] = new ImageIcon("src//picture//b2.png");
		whiteCh[0] = new ImageIcon("src//picture//w1.jpg");
		whiteCh[1] = new ImageIcon("src//picture//w2.png");
		
		for(int i = 0; i < 8; i++)//�ŧi�C��
			for(int j = 0; j < 8; j++) {
				if((i+j)%2 == 0) {
					table[i][j] = new JLabel(backImage[0]);
					table[i][j].setBounds(j*120, i*120, 120, 120);
					cp.add(table[i][j]);
					int a = i, b = j;
					table[i][j].addMouseListener(new java.awt.event.MouseAdapter() {
						public void mousePressed(MouseEvent e) {
							if(r.cnt%2 == 1)
								r.putChess((byte)2, (byte)(a+1), (byte)(b+1));
							else
								r.putChess((byte)1, (byte)(a+1), (byte)(b+1));
							System.out.println(a+","+b);
						}
					});
				}
				else {
					table[i][j] = new JLabel(backImage[1]);	
					table[i][j].setBounds(j*120, i*120, 120, 120);
					cp.add(table[i][j]);
					int a = i, b = j;
					table[i][j].addMouseListener(new java.awt.event.MouseAdapter() {
						public void mousePressed(MouseEvent e) {
							if(r.cnt%2 == 1)
								r.putChess((byte)2, (byte)(a+1), (byte)(b+1));
							else
								r.putChess((byte)1, (byte)(a+1), (byte)(b+1));
							System.out.println(a+","+b);
						}
					});
				}
			}
		
		this.setTitle("HomeWork");
		this.setSize(960+6,960+30);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
