
public class Reversi {
	
	static JFrametable f;
	static byte cnt = 1;
	static byte[] [] table;
	static byte moveX[] = {0, 1, 1, 1, 0, -1, -1, -1};
	static byte moveY[] = {1, 1, 0, -1, -1, -1, 0, 1};

   	public static void tableInitial(byte c){
   		table = new byte[10][10];
   		for (int i = 0; i < table.length; i++){
   			table[0][i] = -1; table[table.length-1][i] = -1;
   			table[i][0] = -1; table[i][table[0].length-1] = -1;

   		}
   		switch (c){
   			case 0:
   				table[4][4] = 1;
   				table[5][5] = 1;
   				table[4][5] = 2;
   				table[5][4] = 2;
   				break;
   			case 1:	
   				table[4][4] = 2;
   				table[5][5] = 2;
   				table[4][5] = 1;
   				table[5][4] = 1;
   				break;
   		}
    }
   	
    public static boolean checkAvailable1(byte c, byte tmpX, byte tmpY, byte path){
    	tmpX += moveX[path]; tmpY += moveY[path];
    	if(c == 1){//white
    		if (table[tmpX][tmpY] == 2) {
    			for(;;) {
    				tmpX += moveX[path]; tmpY += moveY[path];
    				if (table[tmpX][tmpY] == 1)
    					return true;
    				else if	(table[tmpX][tmpY] == 2)
    					continue;
    				else
    					return false;
    					
    			}
    		}
    		else
    			return false;
    	}
    	else if(c == 2){//black
    		if (table[tmpX][tmpY] == 1) {
    			for(;;) {
    				tmpX += moveX[path]; tmpY += moveY[path];
    				if (table[tmpX][tmpY] == 2)
    					return true;
    				else if	(table[tmpX][tmpY] == 1)
    					continue;
    				else
    					return false;
    					
    			}
    		}
    		else
    			return false;	
    	}
    	else
    		return false;
    }
    
    public static void drawTable(){
    	for (int i = 1; i < table.length-1; i++){
    		for (int j = 1; j < table[0].length-1; j++){
    			if(table[i+1][j+1] == 1) {
    				if((i+j)%2 == 0)
    					f.table[i][j].setIcon(f.whiteCh[0]);
    				else
    					f.table[i][j].setIcon(f.whiteCh[1]);
    			}   			
    			if(table[i+1][j+1] == 2) {
    				if((i+j)%2 == 0)
    					f.table[i][j].setIcon(f.blackCh[0]);
    				else
    					f.table[i][j].setIcon(f.blackCh[1]);	
    			}
    		}
    	}
    }
    
    public static void whiteAvailable() {
		for(int i = 1; i <= 8; i++)
			for(int j = 1; j <= 8; j++)
				for(int k = 0; k < 8; k++)
					if(checkAvailable1((byte)1,(byte)i,(byte)j,(byte)k))
						f.table[i-1][j-1].setIcon(f.wa);
    }
    
    public static boolean blackAvailable() {
		for(int i = 1; i <= 8; i++)
			for(int j = 1; j <= 8; j++)
				for(int k = 0; k < 8; k++)
					if(checkAvailable1((byte)2,(byte)i,(byte)j,(byte)k)) {
						f.table[i-1][j-1].setIcon(f.ba);
						return true;
					}
		return false;
    }
    
    public static void eatChess(byte c, byte tmpX, byte tmpY, byte path) {
    	if(c == 1) {
        	for(;;) {
        		tmpX += moveX[path]; tmpY += moveY[path];
        		if(table[tmpX][tmpY] == 1)
        			break;
        		f.table[tmpX-1][tmpY-1].setIcon(f.whiteCh[(tmpX+tmpY)%2]);
        		table[tmpX][tmpY] = 1;
        	}	
    	}
    	else {
        	for(;;) {
        		tmpX += moveX[path]; tmpY += moveY[path];
        		if(table[tmpX][tmpY] == 2)
        			break;
        		f.table[tmpX-1][tmpY-1].setIcon(f.blackCh[(tmpX+tmpY)%2]);
        		table[tmpX][tmpY] = 2;
        	}	
    	}
    }
    
    public static void putChess(byte c, byte tmpX, byte tmpY) {
    	boolean ca = false;
    	if(c == 1) {
    		if(table[tmpX][tmpY] == 0) {
        		for(int i = 0; i < 8; i++)
        			if(checkAvailable1(c, tmpX, tmpY, (byte)i)) {
        				f.table[tmpX-1][tmpY-1].setIcon(f.whiteCh[(tmpX+tmpY)%2]);
        				eatChess(c, tmpX, tmpY, (byte)i);
        				table[tmpX][tmpY] = 1;
        				ca = true;
        			}	
    		}
    	}
    	else if(c == 2) {
    		if(table[tmpX][tmpY] == 0) {
        		for(int i = 0; i < 8; i++)
        			if(checkAvailable1(c, tmpX, tmpY, (byte)i)) {
        				f.table[tmpX-1][tmpY-1].setIcon(f.blackCh[(tmpX+tmpY)%2]);
        				eatChess(c, tmpX, tmpY, (byte)i);
        				table[tmpX][tmpY] = 2;
        				ca = true;
        			}	
    		}
    	}
    	if(ca == true)
    		cnt++;
    	System.out.print(cnt);
    }
    
	public static void main(String[] args) {
		
	    f = new JFrametable();
		tableInitial((byte)1);
		drawTable();
	}
}